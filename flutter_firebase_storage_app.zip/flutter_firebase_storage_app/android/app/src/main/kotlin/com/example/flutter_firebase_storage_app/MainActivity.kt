package com.example.flutter_firebase_storage_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
