package com.example.hive_flutter_tutorial_yt

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
